<?php
/**
 * Stripe API Keys Configuration
 * 
 * IMPORTANT SECURITY NOTES:
 * 1. This file contains sensitive API keys
 * 2. NEVER commit this file to version control (Git)
 * 3. Keep this file outside the web root if possible
 * 4. Set proper file permissions (chmod 600 on Linux/Mac)
 * 
 * To get your Stripe keys:
 * 1. Go to https://dashboard.stripe.com/
 * 2. Navigate to Developers > API keys
 * 3. Copy your "Publishable key" (starts with pk_test_ or pk_live_)
 * 4. Copy your "Secret key" (starts with sk_test_ or sk_live_)
 * 
 * Test keys (for development):
 * - pk_test_... / sk_test_...
 * 
 * Live keys (for production):
 * - pk_live_... / sk_live_...
 */

// Stripe Secret Key (Server-side only - NEVER expose in frontend)
define('STRIPE_SECRET_KEY', 'sk_test_51SFZTeFZetT6fppMP2b623L7m8VxgT8QOjEOCoiAn0yecOsiJxK14UL4BtH7Fh5OgDeyqiFpAKbSHhVT3cr3fiyH00sRQ0eaPN');

// Stripe Publishable Key (Safe to use in frontend/browser)
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51SFZTeFZetT6fppMXO3CMbwUEfzCdEKbn9wlyDFnqMUGZWVQzsenp6jzWM3NAedklviHaCIl1P30Nc1n47aa6rwM00RYn3J6d4');

