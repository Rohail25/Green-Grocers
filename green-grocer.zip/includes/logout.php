<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/config.php'; // defines BASE_PATH
require_once __DIR__ . '/auth.php';

logoutUser();
?>
